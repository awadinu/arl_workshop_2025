import rclpy
from rclpy.node import Node
from std_msgs.msg import String

class ShapeNode(Node):
    def __init__(self):
        super().__init__('shapeNode')
        self.pub = self.create_publisher(String, 'shape_selection', 10)
        self.get_logger().info("Type: ellipse, star, or infinity")

def main(args=None):
    rclpy.init(args=args)
    node = ShapeNode()
    try:
        while rclpy.ok():
            try:
                s = input("> ").strip().lower()
            except EOFError:
                break
            if not s:
                continue
            msg = String()
            msg.data = s
            node.pub.publish(msg)
            node.get_logger().info(f"sent: {s}")
    finally:
        node.destroy_node()
        rclpy.shutdown()

if __name__ == "__main__":
    main()
