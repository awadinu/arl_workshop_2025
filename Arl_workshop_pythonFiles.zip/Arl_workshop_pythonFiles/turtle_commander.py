import rclpy
from rclpy.node import Node
from std_msgs.msg import String
from geometry_msgs.msg import Twist
import math
from turtlesim.srv import TeleportAbsolute

class TurtleCommander(Node):

    def __init__(self):
        super().__init__('turtle_commander')
        self.get_logger().info('Turtle Commander Node started')

        self.subscription = self.create_subscription(String, 'shape_selection', self.shape_callback, 10)

        self.turtle_publisher_ = self.create_publisher(Twist, 'turtle1/cmd_vel', 10)
        self.turtle_cmd = Twist()

        # shape flags
        self.shape1_stop = True
        self.shape2_stop = True
        self.shape3_stop = True

        # state for star drawing
        self.phase = 0
        self.forward_steps = 0
        self.turn_steps = 0
        self.forward_limit = 10
        self.turn_angle_deg = 144
        self.angular_speed = 1.0
        self.timer_period = 0.1
        self.turn_limit = int((self.turn_angle_deg * math.pi / 180.0) / (self.angular_speed * self.timer_period))

        self.timer = self.create_timer(self.timer_period, self.update)

        self.t = 0.0
        self.dt = 0.05
                
        self.teleport_client = self.create_client(TeleportAbsolute, '/turtle1/teleport_absolute')
        while not self.teleport_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info("Waiting for /turtle1/teleport_absolute service...")

    def teleport_turtle(self, x, y, theta):
        req = TeleportAbsolute.Request()
        req.x = x
        req.y = y
        req.theta = theta
        self.teleport_client.call_async(req)

    def shape_callback(self, msg):
        shape = msg.data
        self.get_logger().info(f"Received shape : {shape}")
        self.t = 0.0

        if shape == 'star':
            self.shape1_stop = False
            self.shape2_stop = True
            self.shape3_stop = True
            self.phase = 0
            self.forward_steps = 0
            self.turn_steps = 0
        elif shape == 'ellipse':
            self.shape1_stop = True
            self.shape2_stop = False
            self.shape3_stop = True
        elif shape == 'infinity':
            self.shape1_stop = True
            self.shape2_stop = True
            self.shape3_stop = False
        else:
            self.stop_all()

    def stop_all(self):
        self.shape1_stop = True
        self.shape2_stop = True
        self.shape3_stop = True
        self.turtle_cmd = Twist()
        self.turtle_publisher_.publish(self.turtle_cmd)

    def update(self):
        if not self.shape1_stop: self.drawStar()
        elif not self.shape2_stop: self.drawEllipse()
        elif not self.shape3_stop: self.drawInfinity()
        else: self.stop_all()

    def drawStar(self):
        twist = Twist()

        if self.phase % 2 == 0:
            twist.linear.x = 2.0
            twist.angular.z = 0.0
            self.forward_steps += 1

            if self.forward_steps >= self.forward_limit:
                self.phase += 1
                self.forward_steps = 0

        else:
            twist.linear.x = 0.0
            twist.angular.z = self.angular_speed
            self.turn_steps += 1

            if self.turn_steps >= self.turn_limit:
                self.phase += 1
                self.turn_steps = 0

        self.turtle_publisher_.publish(twist)

        # 5 edges + 5 turns
        if self.phase >= 10:
            self.get_logger().info("Star completed")
            self.stop_all()

    def drawEllipse(self):
        # Parametric ellipse: x = a cos(t), y = b sin(t)
        a, b = 2.5, 1.5
        x_dot = -a * math.sin(self.t)
        y_dot = b * math.cos(self.t)

        v = math.sqrt(x_dot**2 + y_dot**2)
        heading = math.atan2(y_dot, x_dot)

        if hasattr(self, "last_heading"):
            dtheta = math.atan2(math.sin(heading - self.last_heading), math.cos(heading - self.last_heading))
            omega = dtheta / self.dt
        else:
            omega = 0.0
        self.last_heading = heading

        twist = Twist()
        twist.linear.x = v * 0.5
        twist.angular.z = omega * 0.5
        self.turtle_publisher_.publish(twist)

        self.t += self.dt
        
        # stop after one full loop
        if self.t >= 2 * math.pi:
            self.get_logger().info("Ellipse completed")
            self.stop_all()
        

    def drawInfinity(self):
        dx = -1.0 * math.sin(self.t)
        dy = 1.0 * (math.cos(self.t)**2 - math.sin(self.t)**2)

        self.turtle_cmd.linear.x = dx
        self.turtle_cmd.linear.y = dy
        self.turtle_publisher_.publish(self.turtle_cmd)

        self.t += self.dt
        
        # stop after one full loop (3shan by7sal shifting besara7a)
        if self.t >= 2 * math.pi:
            self.get_logger().info("Infinity completed")
            self.stop_all()

def main(args=None):
    rclpy.init(args=args)
    turtle_commander = TurtleCommander()
    rclpy.spin(turtle_commander)
    turtle_commander.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()
